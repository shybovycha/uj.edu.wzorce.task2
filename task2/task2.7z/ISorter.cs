﻿using System;
using System.Collections.Generic;

namespace task2
{
    public interface ISorter
    {
        List<int> sort(List<int> numbers);
    }
}

